/*******************************************************************************
 * $Id: Messages.java,v 1.2 2013/03/24 04:08:57 randallco Exp $
 * 
 * Copyright (c) 2003-2013 Randallco (randallco@users.sourceforge.net)
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *      Randallco (randallco@users.sourceforge.net)
 *******************************************************************************/
package net.sourceforge.ehep.preferences;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "net.sourceforge.ehep.preferences.messages"; //$NON-NLS-1$
	public static String PreferencesPage_0;
	public static String PreferencesPage_1;
	public static String PreferencesPage_12;
	public static String PreferencesPage_15;
	public static String PreferencesPage_18;
	public static String PreferencesPage_2;
	public static String PreferencesPage_21;
	public static String PreferencesPage_24;
	public static String PreferencesPage_27;
	public static String PreferencesPage_3;
	public static String PreferencesPage_31;
	public static String PreferencesPage_32;
	public static String PreferencesPage_33;
	public static String PreferencesPage_34;
	public static String PreferencesPage_35;
	public static String PreferencesPage_36;
	public static String PreferencesPage_37;
	public static String PreferencesPage_38;
	public static String PreferencesPage_39;
	public static String PreferencesPage_4;
	public static String PreferencesPage_40;
	public static String PreferencesPage_41;
	public static String PreferencesPage_42;
	public static String PreferencesPage_5;
	public static String PreferencesPage_6;
	public static String PreferencesPage_7;
	public static String PreferencesPage_8;
	public static String PreferencesPage_9;
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
