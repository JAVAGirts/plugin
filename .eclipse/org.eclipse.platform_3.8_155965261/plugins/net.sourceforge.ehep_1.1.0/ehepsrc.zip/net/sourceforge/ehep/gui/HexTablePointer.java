/*******************************************************************************
 * $Id: HexTablePointer.java,v 1.4 2013/03/24 04:08:57 randallco Exp $
 * 
 * Copyright (c) 2003-2013 Randallco (randallco@users.sourceforge.net)
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *      Randallco (randallco@users.sourceforge.net)
 *******************************************************************************/
package net.sourceforge.ehep.gui;

import net.sourceforge.ehep.core.EHEP;

/**
 * @author Randallco
 * @author randallco@users.sourceforge.net
 */
public class HexTablePointer {

	private int rowIndex;
	private int columnIndex;
	
	public HexTablePointer(int rowIndex, int columnIndex) {
		super();
		this.rowIndex = rowIndex;
		this.columnIndex = columnIndex;
	}

	public HexTablePointer(int offset) {
		move(offset);
	}

	/**
	 * Zero-based projection from the pointer position (row,column) to index 
	 * @return zero-based position index
	 */
	public int getOffset() {
		return rowIndex * EHEP.TABLE_NUM_DATA_COLUMNS + columnIndex;
	}
	
	public int getRowIndex() {
		return rowIndex;
	}

	public int getColumnIndex() {
		return columnIndex;
	}

	public HexTablePointer move(int offset) {
		int newOffset = getOffset() + offset;
		rowIndex = newOffset / EHEP.TABLE_NUM_DATA_COLUMNS;
		columnIndex = newOffset % EHEP.TABLE_NUM_DATA_COLUMNS;
		return this;
	}
	
	public boolean equals(HexTablePointer p) {
		return (rowIndex == p.getRowIndex() && columnIndex == p.getColumnIndex());
	}

	public HexTablePointer adjust() {
		if (rowIndex < 0) rowIndex = 0;
		if (columnIndex < 0) columnIndex = 0;
		return this;
	}
	
	public String toString() {
		return Messages.HexTablePointer_0 + rowIndex + Messages.HexTablePointer_1 + columnIndex + ")"; //$NON-NLS-3$
	}
}
