/*******************************************************************************
 * $Id: Messages.java,v 1.2 2013/03/24 04:08:57 randallco Exp $
 * 
 * Copyright (c) 2003-2013 Randallco (randallco@users.sourceforge.net)
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *      Randallco (randallco@users.sourceforge.net)
 *******************************************************************************/
package net.sourceforge.ehep.core;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "net.sourceforge.ehep.core.messages"; //$NON-NLS-1$
	public static String EHEP_3;
	public static String EHEP_4;
	public static String EHEP_5;
	public static String FileManager_0;
	public static String FileManager_11;
	public static String FileManager_13;
	public static String FileManager_14;
	public static String FileManager_15;
	public static String FileManager_16;
	public static String FileManager_18;
	public static String FileManager_19;
	public static String FileManager_20;
	public static String FileManager_22;
	public static String FileManager_23;
	public static String FileManager_24;
	public static String FileManager_26;
	public static String FileManager_28;
	public static String FileManager_3;
	public static String FileManager_30;
	public static String FileManager_32;
	public static String FileManager_6;
	public static String FileManager_9;
	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
